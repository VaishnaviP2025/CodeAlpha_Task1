# Word and Character Counter
<hr>
<p align="right">Created and designed by AD Singh
<hr>
I have used <b>JDK1.8</b> to compile the source code
<br>
<p>Thanx for using <u>Word and Character Counter Program</u></p>

<div align="center"><img src="1.jpg" width="350px" ></div>


For more visit <a href="http://projects.adsingh.net/">projects.adsingh.net !</a>

##### If you find any bug in this software, please inform me. I also want to welcome any of your suggestions about this program. Thanks for using this software.

